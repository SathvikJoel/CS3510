#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1;
  // tracing functionality
  if( myproc()->trace_arg >> 2 )
  {
	  printf("arg0 : %d\n",n);
  }

  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  if(argaddr(0, &p) < 0)
    return -1;
  
  // tracing functionality
  if( myproc()->trace_arg >> 3 )
  {
	  printf("arg0 : %d\n",p);
  }
  return wait(p);
}

uint64
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
	
	// Lab3 OS
	// just the size is increased but the pages are not allocated
  myproc()->sz += n;

  //if(growproc(n) < 0)
  //  return -1;

  // tracing functionality
  if( myproc()->trace_arg >> 12 )
  {
	  printf("arg0 : %d\n",n);
  }

  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  printf("Sleeping for %d ticks\n", n );
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);

  // tracing functionality
  if( myproc()->trace_arg >> 13 )
  {
	  printf("arg0 : %d\n",n);
  }
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// prints the argument given from kernel
uint64
sys_echo_simple(void)
{

	char str[MAXPATH];
	if( argstr(0, str, MAXPATH ) < 0 ) return -1;

	printf("%s\n",str);


	  // tracing functionality
	  if( myproc()->trace_arg >> 22 )
	  {
		  printf("arg0 : %s\n",str);
	  }

	return strlen(str);
}

// extention of echo_simple prints all the arguments from kernel space
uint64
sys_echo_kernel(void)
{
	int n ;
	char* argv[1000];
	uint64 nargv, narg;

	if(argint(0, &n)<0||argaddr(1,&nargv)<0){
		return -1;
	}
	for(int i = 1; i < n ; i++){
		if(fetchaddr(nargv+sizeof(uint64)*i, (uint64*)&narg) < 0) {return -1;}
		argv[i] = "\0";
		if( fetchstr(narg, argv[i], 4096)<0){return -1;}
		printf("%s ",argv[i]);
	}
	printf("\n");

	  // tracing functionality
	  if( myproc()->trace_arg >> 23 )
	  {
		  printf("arg0 : %d\n",n);
		  printf("arg1 : %d\n",nargv);
	  }

	return 0;
}

// adds the mask to the proc and starts to trace it
uint64
sys_trace(void)
{
	int n;
	if(argint(0, &n) < 0)
		return -1;

	struct proc*p = myproc();
	p->trace_arg = n;
	return n;	
}
