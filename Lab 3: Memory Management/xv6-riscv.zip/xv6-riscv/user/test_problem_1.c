#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc ,char ** argv)
{
	if( argc == 1 )
	{
		printf("Error: Expecting 2 arguments recieved only one\n");
		exit(0);
	}
	echo_simple(argv[1]);
	exit(0);
}

