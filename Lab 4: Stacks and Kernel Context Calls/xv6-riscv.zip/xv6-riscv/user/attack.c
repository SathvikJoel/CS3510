#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


int
main(int argc, char *argv[])
{
  //int pid ;
  //pid = fork();
  //if( pid > 0){
  //    //wait();
  //    sleep(1);
  //    printf("Parent Process : \n");
  //    //pcbread();
  //}
  //else{
  //    printf("Child Process : \n");
  //    //pcbread();
  //}
    sleep(10);

  exit(0);
}
